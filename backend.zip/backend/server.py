#!/usr/bin/env python3
"""
YouTube Video Extraction Server for JJUTV (Blippi Kids App)
Uses yt-dlp to extract video streams and serves them via REST API
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import yt_dlp
import logging
from datetime import datetime, timedelta
from functools import lru_cache
import json

app = Flask(__name__)
CORS(app)  # Enable CORS for Android app

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Blippi channel IDs
BLIPPI_CHANNELS = [
    'UC5PYHgAzJ1jQzoyDQjOA1RA',  # Blippi - Educational Videos for Kids
    'UCqwjm_R3H1F6i8KBYmPh82A'   # Blippi Toys
]

# yt-dlp options for best extraction
YDL_OPTS = {
    # Simpler format selection - get any working stream
    # ExoPlayer can handle various formats including DASH
    'format': 'best',
    'quiet': False,  # Show errors for debugging
    'no_warnings': False,
    'extract_flat': False,
    'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
}

# Cache for 1 hour to reduce YouTube requests
cache_timeout = timedelta(hours=1)
video_cache = {}

@app.route('/')
def index():
    """Health check endpoint"""
    return jsonify({
        'status': 'online',
        'service': 'JJUTV Video Extraction Server',
        'version': '1.0',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/extract', methods=['GET', 'POST'])
def extract_video():
    """
    Extract video stream URL from YouTube video ID

    Query params:
        video_id: YouTube video ID (required)
        quality: Preferred quality (optional, default: best)

    Returns:
        JSON with video URL, title, thumbnail, etc.
    """
    try:
        # Get video ID from query params or JSON body
        video_id = request.args.get('video_id') or request.json.get('video_id')

        if not video_id:
            return jsonify({'error': 'video_id is required'}), 400

        logger.info(f"Extracting video: {video_id}")

        # Check cache
        cache_key = f"video_{video_id}"
        if cache_key in video_cache:
            cached_data, cache_time = video_cache[cache_key]
            if datetime.now() - cache_time < cache_timeout:
                logger.info(f"Returning cached data for {video_id}")
                return jsonify(cached_data)

        # Extract video info using yt-dlp
        url = f'https://www.youtube.com/watch?v={video_id}'

        with yt_dlp.YoutubeDL(YDL_OPTS) as ydl:
            info = ydl.extract_info(url, download=False)

            # Get best format URL
            video_url = info.get('url')

            # If no direct URL, try formats
            if not video_url and 'formats' in info:
                formats = info['formats']
                # Prefer format with both video and audio
                format_with_audio = next(
                    (f for f in formats if f.get('acodec') != 'none' and f.get('vcodec') != 'none'),
                    None
                )
                if format_with_audio:
                    video_url = format_with_audio.get('url')
                elif formats:
                    video_url = formats[-1].get('url')

            if not video_url:
                return jsonify({'error': 'Could not extract video URL'}), 500

            # Prepare response
            response_data = {
                'success': True,
                'video_id': video_id,
                'url': video_url,
                'title': info.get('title', 'Unknown'),
                'duration': info.get('duration', 0),
                'thumbnail': info.get('thumbnail', ''),
                'description': info.get('description', ''),
                'uploader': info.get('uploader', ''),
                'view_count': info.get('view_count', 0),
                'extracted_at': datetime.now().isoformat()
            }

            # Cache the result
            video_cache[cache_key] = (response_data, datetime.now())

            logger.info(f"Successfully extracted: {info.get('title')}")
            return jsonify(response_data)

    except Exception as e:
        logger.error(f"Error extracting video {video_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e),
            'video_id': video_id
        }), 500

@app.route('/api/channel/blippi', methods=['GET'])
def get_blippi_videos():
    """
    Fetch latest Blippi channel videos

    Query params:
        max_results: Maximum number of videos (default: 50)
        channel: Specific channel index (0 or 1, default: both)

    Returns:
        JSON array of video objects
    """
    try:
        max_results = int(request.args.get('max_results', 50))
        channel_index = request.args.get('channel')

        logger.info(f"Fetching Blippi videos (max: {max_results})")

        # Check cache
        cache_key = f"blippi_channel_{max_results}_{channel_index}"
        if cache_key in video_cache:
            cached_data, cache_time = video_cache[cache_key]
            if datetime.now() - cache_time < cache_timeout:
                logger.info("Returning cached Blippi videos")
                return jsonify(cached_data)

        all_videos = []
        channels_to_fetch = BLIPPI_CHANNELS if channel_index is None else [BLIPPI_CHANNELS[int(channel_index)]]

        for channel_id in channels_to_fetch:
            logger.info(f"Fetching from channel: {channel_id}")

            url = f'https://www.youtube.com/channel/{channel_id}/videos'

            opts = YDL_OPTS.copy()
            opts['extract_flat'] = True
            opts['playlistend'] = max_results

            with yt_dlp.YoutubeDL(opts) as ydl:
                try:
                    info = ydl.extract_info(url, download=False)

                    if 'entries' in info:
                        for entry in info['entries'][:max_results]:
                            video_id = entry.get('id')
                            if video_id:
                                all_videos.append({
                                    'video_id': video_id,
                                    'title': entry.get('title', 'Blippi Video'),
                                    'thumbnail': entry.get('thumbnail', f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg'),
                                    'url': f'https://www.youtube.com/watch?v={video_id}',
                                    'duration': entry.get('duration', 0),
                                    'uploader': entry.get('uploader', 'Blippi')
                                })
                except Exception as e:
                    logger.warning(f"Failed to fetch from channel {channel_id}: {str(e)}")
                    continue

        response_data = {
            'success': True,
            'videos': all_videos[:max_results],
            'count': len(all_videos[:max_results]),
            'fetched_at': datetime.now().isoformat()
        }

        # Cache the result
        video_cache[cache_key] = (response_data, datetime.now())

        logger.info(f"Successfully fetched {len(all_videos)} Blippi videos")
        return jsonify(response_data)

    except Exception as e:
        logger.error(f"Error fetching Blippi videos: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e),
            'videos': []
        }), 500

@app.route('/api/playlist', methods=['GET', 'POST'])
def extract_playlist():
    """
    Extract all videos from a YouTube playlist

    Query params:
        playlist_id: YouTube playlist ID (required)
        max_results: Maximum number of videos (default: 50)

    Returns:
        JSON array of video objects
    """
    try:
        playlist_id = request.args.get('playlist_id') or request.json.get('playlist_id')
        max_results = int(request.args.get('max_results', 50))

        if not playlist_id:
            return jsonify({'error': 'playlist_id is required'}), 400

        logger.info(f"Fetching playlist: {playlist_id}")

        url = f'https://www.youtube.com/playlist?list={playlist_id}'

        opts = YDL_OPTS.copy()
        opts['extract_flat'] = True
        opts['playlistend'] = max_results

        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)

            videos = []
            if 'entries' in info:
                for entry in info['entries'][:max_results]:
                    video_id = entry.get('id')
                    if video_id:
                        videos.append({
                            'video_id': video_id,
                            'title': entry.get('title', 'Video'),
                            'thumbnail': entry.get('thumbnail', f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg'),
                            'url': f'https://www.youtube.com/watch?v={video_id}',
                            'duration': entry.get('duration', 0)
                        })

            return jsonify({
                'success': True,
                'playlist_id': playlist_id,
                'playlist_title': info.get('title', 'Playlist'),
                'videos': videos,
                'count': len(videos),
                'fetched_at': datetime.now().isoformat()
            })

    except Exception as e:
        logger.error(f"Error fetching playlist {playlist_id}: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/cache/clear', methods=['POST'])
def clear_cache():
    """Clear the video cache"""
    global video_cache
    cache_size = len(video_cache)
    video_cache.clear()
    logger.info(f"Cache cleared ({cache_size} entries)")
    return jsonify({
        'success': True,
        'message': f'Cleared {cache_size} cache entries'
    })

if __name__ == '__main__':
    # Run server
    # For production, use gunicorn or similar WSGI server
    app.run(host='0.0.0.0', port=5000, debug=True)
